﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void cadastro_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(nome.Text + cpf.Text + ".txt"))
                {
                    StreamWriter sw = new StreamWriter(nome.Text + cpf.Text + ".txt", true);
                    sw.WriteLine("Nome:" + nome.Text);
                    sw.WriteLine("Senha:" + senha.Text);
                    sw.WriteLine("Email:" + email.Text);
                    sw.WriteLine("Site:" + site.Text);
                    sw.WriteLine("Telefone:" + Telefone.Text);
                    sw.WriteLine("Celular:" + Celular.Text);
                    sw.WriteLine("Endereço:" + endereço.Text);
                    sw.WriteLine("CPF:" + cpf.Text);
                    sw.WriteLine("RG" + rg.Text);
                    sw.WriteLine("Sexo" + sexo.Text);
                    sw.Close();
                    MessageBox.Show("Seu usário é:" + nome.Text + cpf.Text, "Sucesso!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();

                }
                else 
                {
                    MessageBox.Show("Usúario existente", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
