﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void cadastro_Click(object sender, EventArgs e)
        {
            Form2 cadastro = new Form2();
            cadastro.ShowDialog();
            user.Clear();
            senha.Clear();
        }

        private void login_Click(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(user.Text + ".txt"))
                {
                    StreamReader sr = new StreamReader(user.Text + ".txt");
                    
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.StartsWith("Senha:"))
                            {
                                string passwordFromFile = line.Substring("Senha:".Length).Trim();
                                if (senha.Text == passwordFromFile)
                                {
                                    Form3 form3 = new Form3();
                                    form3.ShowDialog();
                                    return;
                                }
                            }
                        
                        }
                        sr.Close();
                }
                else
                {
                    MessageBox.Show("Usúario ou senha incorretos ou não existentes");
                    
                }
                user.Clear();
                senha.Clear();
            }
            catch (Exception ex) { }
        }
    }
}
